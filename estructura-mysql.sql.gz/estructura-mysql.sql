-- Adminer 3.3.3 MySQL dump

SET NAMES utf8;
SET foreign_key_checks = 0;
SET time_zone = 'SYSTEM';
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `clientes`;
CREATE TABLE `clientes` (
  `cliente_id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  `telefono` varchar(15) NOT NULL,
  `celular` varchar(15) NOT NULL,
  `direccion` varchar(255) NOT NULL,
  `CP` varchar(10) NOT NULL,
  `RFC` varchar(20) NOT NULL,
  PRIMARY KEY (`cliente_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `detalle_ventas`;
CREATE TABLE `detalle_ventas` (
  `venta_id` int(11) NOT NULL,
  `codigo` varchar(60) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `descuento` int(11) NOT NULL,
  KEY `codigo` (`codigo`),
  KEY `venta_id` (`venta_id`),
  CONSTRAINT `detalle_ventas_ibfk_2` FOREIGN KEY (`codigo`) REFERENCES `productos` (`codigo`),
  CONSTRAINT `detalle_ventas_ibfk_3` FOREIGN KEY (`venta_id`) REFERENCES `ventas` (`venta_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DELIMITER ;;

CREATE TRIGGER `detalle_ventas_bi` BEFORE INSERT ON `detalle_ventas` FOR EACH ROW
update productos set existencia=existencia-new.cantidad where codigo=new.codigo;;

CREATE TRIGGER `detalle_ventas_bd` BEFORE DELETE ON `detalle_ventas` FOR EACH ROW
update productos set existencia=existencia+old.cantidad where codigo=old.codigo;;

DELIMITER ;

DROP TABLE IF EXISTS `productos`;
CREATE TABLE `productos` (
  `producto_id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` varchar(60) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `descripcion` varchar(250) NOT NULL,
  `precio` float NOT NULL,
  `existencia` int(11) NOT NULL,
  PRIMARY KEY (`producto_id`),
  UNIQUE KEY `codigo` (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE `usuarios` (
  `usuario_id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(30) NOT NULL,
  `usuario` varchar(20) NOT NULL,
  `contrasena` varchar(100) NOT NULL,
  `nivel_id` int(11) NOT NULL,
  PRIMARY KEY (`usuario_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `usuarios` (`usuario_id`, `nombre`, `usuario`, `contrasena`, `nivel_id`) VALUES
(1,	'Nancy',	'nancy',	'922ee38aef5bb19b88a7107881481f0460935afb',	1),
(2,	'Edgar',	'heli',	'4bea5b1c1cc19755b65c6389a2be1a2fcdae5c4b',	1),
(3,	'Eleazar',	'eleazar',	'42b35d5e8f05a514d652e96e50fb2c37e56a21a6',	1);

DROP TABLE IF EXISTS `ventas`;
CREATE TABLE `ventas` (
  `venta_id` int(11) NOT NULL AUTO_INCREMENT,
  `cliente_id` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `hora` time NOT NULL,
  `notas` text NOT NULL,
  `total` float NOT NULL,
  `pagado` float NOT NULL,
  `usuario_id` int(11) NOT NULL,
  PRIMARY KEY (`venta_id`),
  KEY `cliente_id` (`cliente_id`),
  CONSTRAINT `ventas_ibfk_1` FOREIGN KEY (`cliente_id`) REFERENCES `clientes` (`cliente_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP VIEW IF EXISTS `busqueda_productos`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `busqueda_productos` AS select `productos`.`codigo` AS `codigo`,`productos`.`nombre` AS `nombre`,`productos`.`precio` AS `precio` from `productos`;

-- 2012-03-14 12:44:32
