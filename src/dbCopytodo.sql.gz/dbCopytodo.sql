-- Adminer 3.3.3 MySQL dump

SET NAMES utf8;
SET foreign_key_checks = 0;
SET time_zone = 'SYSTEM';
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `clientes`;
CREATE TABLE `clientes` (
  `cliente_id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(60) NOT NULL,
  `apellidos` varchar(60) NOT NULL,
  `telefono` varchar(15) NOT NULL,
  `celular` varchar(15) NOT NULL,
  `direccion` varchar(255) NOT NULL,
  PRIMARY KEY (`cliente_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `clientes` (`cliente_id`, `nombre`, `apellidos`, `telefono`, `celular`, `direccion`) VALUES
(1,	'Cliente0',	'Apellidos 0',	'00000',	'00000',	'Dasdsa'),
(2,	'Cliente1',	'Apellidos 1',	'11111',	'11111',	'Dasdsa'),
(3,	'Cliente2',	'Apellidos 2',	'22222',	'22222',	'Dasdsa'),
(4,	'Cliente3',	'Apellidos 3',	'33333',	'33333',	'Dasdsa'),
(5,	'Cliente4',	'Apellidos 4',	'44444',	'44444',	'Dasdsa'),
(6,	'Cliente5',	'Apellidos 5',	'55555',	'55555',	'Dasdsa'),
(7,	'Cliente6',	'Apellidos 6',	'66666',	'66666',	'Dasdsa'),
(8,	'Cliente7',	'Apellidos 7',	'77777',	'77777',	'Dasdsa'),
(9,	'Cliente8',	'Apellidos 8',	'88888',	'88888',	'Dasdsa'),
(10,	'Cliente9',	'Apellidos 9',	'99999',	'99999',	'Dasdsa');

DROP TABLE IF EXISTS `detalle_ventas`;
CREATE TABLE `detalle_ventas` (
  `venta_id` int(11) NOT NULL,
  `codigo` varchar(60) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `descuento` int(11) NOT NULL,
  KEY `codigo` (`codigo`),
  KEY `venta_id` (`venta_id`),
  CONSTRAINT `detalle_ventas_ibfk_2` FOREIGN KEY (`codigo`) REFERENCES `productos` (`codigo`),
  CONSTRAINT `detalle_ventas_ibfk_3` FOREIGN KEY (`venta_id`) REFERENCES `ventas` (`venta_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `detalle_ventas` (`venta_id`, `codigo`, `cantidad`, `descuento`) VALUES
(1,	'124',	1,	0),
(2,	'001',	0,	0),
(2,	'127',	1,	0),
(3,	'126',	1,	0),
(4,	'128',	1,	0),
(5,	'124',	1,	0),
(6,	'126',	1,	0),
(7,	'122',	1,	0),
(7,	'123',	0,	0);

DELIMITER ;;

CREATE TRIGGER `detalle_ventas_bi` BEFORE INSERT ON `detalle_ventas` FOR EACH ROW
update productos set existencia=existencia-new.cantidad where codigo=new.codigo;;

CREATE TRIGGER `detalle_ventas_bd` BEFORE DELETE ON `detalle_ventas` FOR EACH ROW
update productos set existencia=existencia+old.cantidad where codigo=old.codigo;;

DELIMITER ;

DROP TABLE IF EXISTS `productos`;
CREATE TABLE `productos` (
  `producto_id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` varchar(60) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `descripcion` varchar(250) NOT NULL,
  `precio` float NOT NULL,
  `existencia` int(11) NOT NULL,
  PRIMARY KEY (`producto_id`),
  UNIQUE KEY `codigo` (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `productos` (`producto_id`, `codigo`, `nombre`, `descripcion`, `precio`, `existencia`) VALUES
(1,	'123',	'Producto de Prueba',	'Sin Descripcion',	50.5,	0),
(2,	'120',	'Producto de Prueba0',	'Sin Descripcion',	50.5,	2),
(3,	'121',	'Producto de Prueba1',	'Sin Descripcion',	150.5,	2),
(4,	'122',	'Producto de Prueba2',	'Sin Descripcion',	250.5,	9),
(6,	'124',	'Producto de Prueba4',	'Sin Descripcion',	450.5,	1),
(7,	'125',	'Producto de Prueba5',	'Sin Descripcion',	550.5,	5),
(8,	'126',	'Producto de Prueba6',	'Sin Descripcion',	650.5,	7),
(9,	'127',	'Producto de Prueba7',	'Sin Descripcion',	750.5,	8),
(10,	'128',	'Producto de Prueba8',	'Sin Descripcion',	850.5,	5),
(11,	'129',	'Producto de Prueba9',	'Sin Descripcion',	950.5,	6),
(12,	'001',	'Nuevo Producto Con nombre muy Largo',	'prueba del formulario',	76.7,	0),
(13,	'',	'',	'',	0,	0),
(14,	'1231',	'Mas producto de prueba',	'otra prueba mas',	12,	100);

DROP TABLE IF EXISTS `usuario`;
CREATE TABLE `usuario` (
  `usuario_id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(30) NOT NULL,
  `usuario` varchar(20) NOT NULL,
  `contrasena` varchar(100) NOT NULL,
  `nivel_id` int(11) NOT NULL,
  PRIMARY KEY (`usuario_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `ventas`;
CREATE TABLE `ventas` (
  `venta_id` int(11) NOT NULL AUTO_INCREMENT,
  `cliente_id` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `hora` time NOT NULL,
  `notas` text NOT NULL,
  `total` float NOT NULL,
  `pagado` float NOT NULL,
  PRIMARY KEY (`venta_id`),
  KEY `cliente_id` (`cliente_id`),
  CONSTRAINT `ventas_ibfk_1` FOREIGN KEY (`cliente_id`) REFERENCES `clientes` (`cliente_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `ventas` (`venta_id`, `cliente_id`, `fecha`, `hora`, `notas`, `total`, `pagado`) VALUES
(1,	1,	'2012-03-04',	'12:24:00',	'',	2,	2),
(2,	1,	'2012-03-04',	'12:35:00',	'',	2,	2),
(3,	1,	'2012-03-04',	'12:36:00',	'',	2,	2),
(4,	1,	'2012-03-04',	'12:38:00',	'',	2,	3),
(5,	1,	'2012-03-04',	'12:44:00',	'',	2,	2),
(6,	1,	'2012-03-04',	'12:46:00',	'',	2,	2),
(7,	1,	'2012-03-04',	'12:46:00',	'',	2,	2);

-- 2012-03-06 14:33:13
